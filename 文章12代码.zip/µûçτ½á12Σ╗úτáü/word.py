string = "   广东省广州市   "
print(f"|{string.strip()}|")