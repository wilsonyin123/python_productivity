string1 = 123.45
print("{:.4f}".format(string1))
print("{:>6d}".format(100))

# 123.4500
#    100